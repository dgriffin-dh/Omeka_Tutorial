## Stroke Color (Selected)

The color of the lines that run around the edges of shapes on the map **when the record is highlighted or selected** - for example, when the cursor hovers or clicks on the shape.

To change the color, click on the input and use the color-picker widget to select a new color. As you edit the value, the record's geometry on the map will automatically update to preview the new color.
