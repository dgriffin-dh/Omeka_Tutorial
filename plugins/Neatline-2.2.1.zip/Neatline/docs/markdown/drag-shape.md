## Drag Shape

Change the location of an existing point, line, or polygon.

  1. Select the "Drag Shape" radio button and click on the shape that you want to drag. You should see a new "control point" appear right in the middle of the shape. If you're dragging an individual point, the point will just change color to indicate that it has been highlighted.

  2. Click and drag on the control point to change the center position of the shape.
