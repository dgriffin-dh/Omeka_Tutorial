## Resize Shape

Expand or shrink an existing line or polygon.

  1. Select the "Resize Shape" radio button and click on the shape that you want to resize. Once the shape is selected, you should see a new "control point" appear to the bottom right of the shape.

  2. Click and drag on the control point to scale the shape.

**Tip**: If you want to change the size of the circle used to represent an individual point, head over to the "Style" tab and change the "Point Radius" option.
